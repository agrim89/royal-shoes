from django.template import Library

register = Library()
