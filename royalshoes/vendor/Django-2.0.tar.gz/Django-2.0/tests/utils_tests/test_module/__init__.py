class SiteMock:
    _registry = {}


site = SiteMock()
